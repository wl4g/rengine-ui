import Init from './Init.vue'
export default Init
