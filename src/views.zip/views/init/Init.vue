<template>
    <div v-loading.fullscreen.lock="fullscreenLoading"></div>
    <!--<div id="logo"/>-->
</template>
<script>
    import Init from './Init.js'
    export default Init
</script>
<!--<style scoped>
    #logo{
        background: url("~@/../static/images/loading/3.gif");
        background-size: 100% 100%;
        height: 100%;
        position: fixed;
        width: 100%
    }
</style>-->
