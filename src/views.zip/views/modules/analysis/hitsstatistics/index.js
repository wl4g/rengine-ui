import Hitsstatistics from "./hitsstatistics.vue"
export default Hitsstatistics
