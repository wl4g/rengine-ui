import ruletemplate from "./ruletemplate.vue"
export default ruletemplate
