import Scenes from "./scenes.vue"
export default Scenes
