import Home from "./home.vue"
export default Home
