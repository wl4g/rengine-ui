import RuleTemplate from "./ruletemplate/"
import RuletemplatesEdit from "./ruletemplate/edit/"

export default {
  RuleTemplate,
  RuletemplatesEdit,
}
