import ruletemplatesEdit from "./edit.vue"
export default ruletemplatesEdit
