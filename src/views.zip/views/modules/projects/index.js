import ProjectList from "./project-list"

export default {
  ProjectList,
}
